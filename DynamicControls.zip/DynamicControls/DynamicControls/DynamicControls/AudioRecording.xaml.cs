﻿using System;
using System.Threading.Tasks;
using MediaManager;
using Plugin.AudioRecorder;
using Xamarin.Forms;

namespace DynamicControls
{	
	public partial class AudioRecording : ContentPage
	{
        AudioRecorderService recorder;

        public AudioRecording()
        {
            InitializeComponent();

            recorder = new AudioRecorderService
            {
                SilenceThreshold = 1,
                StopRecordingOnSilence = false, //will stop recording after 2 seconds (default)  
                StopRecordingAfterTimeout = true,  //stop recording after a max timeout (defined below)  
                TotalAudioTimeout = TimeSpan.FromSeconds(180) //audio will stop recording after 3 minutes  
            };

            recorder.AudioInputReceived += Recorder_AudioInputReceived;
        }

        private void Recorder_AudioInputReceived(object sender, string e)
        {
            btnRecord.Text = "Record";
        }

        async void PlayButton_Clicked(System.Object sender, System.EventArgs e)
        {
            if (recorder.IsRecording)
            {
                btnRecord.Text = "Record";
                await recorder.StopRecording();
            }

            if (recorder.FilePath != null) 
            {
                var path = recorder.FilePath;

                await CrossMediaManager.Current.Play("file://" + path);
            }
        }

        async void RecordButton_Click(object sender, EventArgs e)
        {
            await RecordAudio();
        }

        async Task RecordAudio()
        {
            try
            {
                if (!recorder.IsRecording)
                {
                    btnRecord.Text = "Stop";
                    await recorder.StartRecording();
                }
                else
                {
                    await recorder.StopRecording();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

}

