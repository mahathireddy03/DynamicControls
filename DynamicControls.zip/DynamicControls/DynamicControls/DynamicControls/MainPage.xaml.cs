﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace DynamicControls
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        void btnLoadControls_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new LoadControlsFromXMLPage());
        }

        void btnRecordAudio_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new AudioRecording());
        }
    }
}

