﻿
namespace DynamicControls
{
    public class Control
    {
        public string Name { get; set; }
        public string Content { get; set; }
    }
}