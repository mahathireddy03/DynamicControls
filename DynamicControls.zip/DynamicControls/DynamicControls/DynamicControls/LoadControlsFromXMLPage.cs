﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Xml.Serialization;
using Xamarin.Forms;

namespace DynamicControls
{
    public class LoadControlsFromXMLPage : ContentPage
    {

        public LoadControlsFromXMLPage()
        {

            var assembly = IntrospectionExtensions.GetTypeInfo(typeof(LoadControlsFromXMLPage)).Assembly;

            foreach (var res in assembly.GetManifestResourceNames())
            {
                System.Diagnostics.Debug.WriteLine(res);
            }

            Stream stream = assembly.GetManifestResourceStream("DynamicControls.XmlFile.xml");

            List<Control> controls;
            using (var reader = new StreamReader(stream))
            {
                var serializer = new XmlSerializer(typeof(List<Control>));
                controls = (List<Control>)serializer.Deserialize(reader);
            }


            var layout = new StackLayout()
            { 
                Margin = new Thickness(20),
                VerticalOptions = LayoutOptions.StartAndExpand
            };

            layout.Children.Add(new Label
            {
                Text = "Adding Controls by reading XML File",
                FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
                FontAttributes = FontAttributes.Bold
            });

            foreach (var item in controls)
            {
                if(item.Name.Trim().Equals("textbox", System.StringComparison.OrdinalIgnoreCase)||
                    item.Name.Trim().Equals("entry", System.StringComparison.OrdinalIgnoreCase))
                {
                    layout.Children.Add(new Entry
                    {
                        Placeholder = item.Content,
                        Margin = new Thickness(20)
                    });
                }
                else if (item.Name.Trim().Equals("dropdown", System.StringComparison.OrdinalIgnoreCase))
                {
                    layout.Children.Add(new Picker
                    {
                        Margin = new Thickness(20)
                    });
                }
                else if (item.Name.Trim().Equals("checkbox", System.StringComparison.OrdinalIgnoreCase))
                {
                    layout.Children.Add(new CheckBox
                    {
                        Margin = new Thickness(20),
                        
                    });
                }
                else if (item.Name.Trim().Equals("radiobutton", System.StringComparison.OrdinalIgnoreCase))
                {
                    layout.Children.Add(new RadioButton
                    {
                        Margin = new Thickness(20),
                        Content = item.Content
                    });
                }
                else if (item.Name.Trim().Equals("label", System.StringComparison.OrdinalIgnoreCase))
                {
                    layout.Children.Add(new Label
                    {
                        Text = item.Content,
                        Margin = new Thickness(20)
                    });
                }
                else if (item.Name.Trim().Equals("button", System.StringComparison.OrdinalIgnoreCase))
                {
                    layout.Children.Add(new Button
                    {
                        Text = item.Content,
                        BackgroundColor = Xamarin.Forms.Color.Blue,
                        TextColor = Color.White,
                        FontAttributes = FontAttributes.Bold,
                        Margin = new Thickness(20)
                    });
                }

            }

            this.Content = layout;
        }
    }
}
